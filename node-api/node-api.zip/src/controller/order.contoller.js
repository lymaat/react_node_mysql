
const db = require("../util/db")
const { isEmptyOrNull } = require("../util/service")


const getAll =  async (req,res) => {
    const list = await db.query("SELECT * FROM order;")
    res.json({
        list  : list
    })
}
const getOne = async (req,res) => {
    const list = await db.query("SELECT * FROM order WHERE order_id = ?",[req.params.id])
    res.json({
        list  : list
    })
}

const getOderByCustomer = async (req,res) => {
    const {customer_id} = req.body;
    const list = await db.query("SELECT * FROM order WHERE customer_id = ?",[customer_id])
    res.json({
        list:list
    })
}

// `customer_id` int(11) NOT NULL,
// `order_status_id` int(11) NOT NULL,
// `payement_methode_id` int(11) NOT NULL,
// `invoice_no` varchar(120) NOT NULL,
// `order_total` decimal(6,0)  NOT NULL,
// `comment` text DEFAULT NULL,

// address_id
// `firstname` varchar(120) NOT NULL,
// `lastname` varchar(120) NOT NULL,
// `telelphone` varchar(18) NOT NULL,
// `address_des` text NOT NULL, 


// `order_id` int(11) NOT NULL,

// get cart
// `product_id` int(11) NOT NULL,
// `quantity` int(11) NOT NULL,
// `price` decimal(6,0) NOT NULL

const create = async (req,res) => {
    try{
        db.beginTransaction()
        // order 
        const {
            customer_id,customer_address_id,payement_methode_id,comment,
        } = req.body;
        const order_status_id = 1 // padding
        const invoice_no = "1212";
        var message = {}
        if(isEmptyOrNull(customer_id)){message.customer_id = "customer_id required!"}
        if(isEmptyOrNull(payement_methode_id)){message.payement_methode_id = "payement_methode_id required!"}
        if(isEmptyOrNull(customer_address_id)){message.customer_address_id = "customer_address_id required!"}
        if(Object.keys(message).length> 0){
            res.json({
                message:message,
                error:true
            })
            return 0;
        }
       
        // find customer_address_info by address_id(from client)
        var address = await db.query("SELECT * FROM customer_address WHERE customer_address_id = ?",[customer_address_id])
        if(address?.length > 0){
            const {firstname,lastname,tel,address_des} = address[0]
            // find total_order => need getCartInfo by customer
            var cart = await db.query("SELECT * FROM cart c.*, p.price INNER JOIN product p ON (c.product_id = p.product_i)  WHERE customer_id = ? ",[customer_id])
           
            // find total amont base from cart by customer
            var order_total = 0;
            cart.map((item,index)=>{
                order_total += (item.quantity * item.price)
            })
            
            // insert data to table order
            var sqlOrder = "INSERT INTO `order`"+
            " (customer_id, payement_methode_id, comment, order_total, firstname, lastname, telelphone, address_des) VALUES "+
            " (?,?,?,?,?,?,?,?)";
            var sqlOrderParam = [customer_id,payement_methode_id,comment,order_total,firstname,lastname,tel,address_des]
            const order = await db.query(sqlOrder,sqlOrderParam)

            // insert order_detail
            cart.map( async (item,index)=>{
                var sqlOorderDetails = "INSERT INTO order_detail (order_id,product_id,quantity,price) VALUES (?,?,?,?)"
                var sqlOorderDetailsParam = [order.insertId, item,product_id, item.quantity, item.price];
                const orderDetail = await db.query(sqlOorderDetails,sqlOorderDetailsParam)
            })
            
            db.commit();
            res.json({
                message:"Your order has been successfully!",
                data:order
            })
            
        }
    
        // // order_detail
        // order_id ?
        // get cart by customer => (product_id,quantity,price)
    }catch(e){
        db.rollback();
    }
    
}

const update = (req,res) => {}
const remove = (req,res) => {}

module.exports = {
    getAll,getOne,update,remove,create,getOderByCustomer
}